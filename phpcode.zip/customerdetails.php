<?php
include("../connection.php");
?>


<!DOCTYPE html>
<html>
<head>
	<title>HM ADMIN</title>
	<link rel="stylesheet" type="text/css" href="../admin.css">
</head>
<body>
	<div id="full">
		<div id="bg1"  style="background-image: url('../img/h1.jpg');width: 100%;height: 600px">
		<div id="header">
			<div id="logo">
				<h1>MY HOTEL</h1>
				<!--<img src="img/logo1.png" height="15px" width="15px">-->
			</div>	


			<div id="nav">
				<ul>
					<li><a href="#">HOME</a></li>
					<li><a href="#">CONTACT US</a></li>
					<li><a href="#">BOOK MY STAY</a></li>
					<li><a href="#">OUR HOTELS</a></li>
					<li><a href="#">HELP</a></li>
				</ul>
			</div>
			</div>
		<div id="banner">

			<div id="form">
				<h1 style="color: white ;margin-left: 8%">ADMIN LOGIN</h1>
					

			
		</div>
		</div>
		</div>
		</div>

</body>
</html>