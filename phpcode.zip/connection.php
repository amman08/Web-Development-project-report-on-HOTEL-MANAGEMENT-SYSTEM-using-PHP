
<?php
$conn1=mysqli_connect('localhost','root','','hd');
?>