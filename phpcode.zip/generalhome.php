<!DOCTYPE html>
<html>
<head>
	<title>HM HOME</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
	<div id="full">
		<div id="bg" style="background-image: url('img/h1.jpg');width: 100%;height: 600px ">
		<div id="header">
			<div id="logo">
				<h1>MY HOTEL</h1>
				

			</div>	


			<div id="nav">
				<ul>
					<li><a href="generalhome.php">HOME</a></li>
					<li><a href="generalservices.php">SERVICES</a></li>
					<li><a href="generalcontact.php">CONTACT US</a></li>
					<li><a href="userlogin.php">BOOKING</a></li>
					<li><a href="Admin/adminlogin.php">ADMIN</a></li>
				</ul>
			</div>

			</div>
		<div id="banner"></div>
		</div>
		</div>

		<div id="welcome">
			<h1 align="center">WELCOME TO THE HOTEL</h1>
			<center><font size="4">
				Personalization is probably the most important point when it comes to creating descriptions for your hotel’s wide array of media content.

				It is imperative that every single visual (whether it’s a photo, video or virtual tour) has its own, unique caption – no matter how similar they may seem. Your hotel’s rooms with one king-size bed are not identical to the rooms which hold two queen-size beds, so why should your photo descriptions be? Vividly explaining the benefits of staying in an upgraded room can even entice travel shoppers to upgrade!
				<h2 style="color: navy">OUR HOTELS</h2>
			</font></center>
		</div>	
		<div id="g1">
			<div id="one"><img src="img/h6.jpg" width=100% >
			<center><h2>Visaka Hotels</h2>
				<font>Hotel Visaka is amazingly beautiful with a very <br>soothing interior and also a very eco friendly terrace with <br>a warm hospitality. A beautiful place to relax and <br>makes us feel at home. i had a great experience during my<br> stay there. The rooms are very classy with all the <br>facilities to fulfil our needs. The food served there is <br>very delicious.</font>
			</center>
			</div>

			<div id="two"><img src="img/h3.jpg" width=100%>
			<center><h2>Hyder Hotels</h2>
			<font>Hotel Hyder is amazingly beautiful with a very soothing <br>interior and also a very eco friendly terrace with a warm hospitality. A beautiful place to relax and makes us feel at<br> home. i had a great experience during my stay there. The rooms<br> are very classy with all the facilities to fulfil our <br>needs. The food served there is very delicious.
				</font>
			</center>
			</div>
			<div id="three"><img src="img/h4.jpg" width=100%>
			<center><h2>Bang Hotels</h2>
			<font>Hotel Bang is amazingly beautiful with a very soothing<br> interior and also a very eco friendly terrace with a warm <br>hospitality. A beautiful place to relax and makes us feel at <br>home. i had a great experience during my stay there. The rooms<br> are very classy with all the facilities to fulfil our <br>needs. The food served there is very delicious.</font>
			</center>
			</div>
		</div>
	</div>

</body>
</body>
</body>
</html>